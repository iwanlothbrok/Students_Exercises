﻿using System;
using System.Collections.Generic;

namespace BitcoinMining
{
    public class Transaction
    {
        public string Name { get; set; }

        public int Value { get; set; }

        public int Weight { get; set; }
    }

    public class StartUp
    {
        public static void Main()
        {
            int transactionCount = int.Parse(Console.ReadLine());

            List<Transaction> transactions = ReadItems(transactionCount);

            int maxCapacity = 1000000;
            int[,] table = new int[transactions.Count + 1, maxCapacity + 1];
            bool[,] included = new bool[transactions.Count + 1, maxCapacity + 1];

            // Implement algorithm here

            SortedSet<string> includedTransactions = new SortedSet<string>();
            int totalValue = table[transactions.Count, maxCapacity];
            int totalWeight = 0;

            for (int row = included.GetLength(0) - 1; row >= 0; row--)
            {
                if (included[row, maxCapacity])
                {
                    Transaction includedTransaction = transactions[row - 1];

                    maxCapacity -= includedTransaction.Weight;
                    totalWeight += includedTransaction.Weight;
                    includedTransactions.Add(includedTransaction.Name);
                }
            }

            Console.WriteLine($"Total Size: {totalWeight}");
            Console.WriteLine($"Total Fees: {totalValue}");
            foreach (string transaction in includedTransactions)
            {
                Console.WriteLine(transaction);
            }
        }

        private static List<Transaction> ReadItems(int transactions)
        {
            List<Transaction> result = new List<Transaction>();

            for (int i = 0; i < transactions; i++)
            {
                string line = Console.ReadLine();

                string[] data = line.Split();
                result.Add(new Transaction
                {
                    Name = data[0],
                    Weight = int.Parse(data[1]),
                    Value = int.Parse(data[2])
                });
            }


            return result;
        }
    }
}
