﻿using RentingCarsSystem.WEB.InputModels.Cars;
using System.ComponentModel.DataAnnotations;

namespace RentingCarsSystem.WEB.InputModels.Renting
{
    public class RentFormModel
    {
        [Required]
        [Display(Name = "First Name")]
        [StringLength(50)]

        public string CustomerFirstName { get; set; } = null!;

        [StringLength(50)]
        [Display(Name = "Last Name")]
        [Required]
        public string CustomerLastName { get; set; } = null!;

        [Required]
        [Display(Name = "Phone Number")]
        public long CustomerPhoneNumber { get; set; }

        [Display(Name = "Date of booking the car")]
        public string BookingDate { get; set; }

        [Display(Name = "Returning date")]
        public string ReturningDate { get; set; }


        [Display(Name = "Address")]
        public string Address { get; set; }

        [Display(Name = "Car")]
        public int CarId { get; init; }

        public IEnumerable<RentCarModel>? Cars { get; set; }
    }
}
