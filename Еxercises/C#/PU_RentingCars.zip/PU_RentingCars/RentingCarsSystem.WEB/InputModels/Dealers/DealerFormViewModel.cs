﻿namespace RentingCarsSystem.WEB.InputModels.Dealers
{
    using System.ComponentModel.DataAnnotations;
    public class DealerFormViewModel
    {
        public int Id { get; set; }

        [Display(Name = "First Name")]
        public string FirstName { get; set; } 

        [Display(Name = "Family Name")]
        public string LastName { get; set; }

        public string Location { get; set; } 

        [Display(Name = "Phone Number")]
        public long? PhoneNumber { get; set; }

        [Display(Name = "Company Name")]
        public string? CompanyName { get; set; }

        // 9 cifri
        public long? Bullstat { get; set; }

        public string? UserId { get; set; }
    }
}
