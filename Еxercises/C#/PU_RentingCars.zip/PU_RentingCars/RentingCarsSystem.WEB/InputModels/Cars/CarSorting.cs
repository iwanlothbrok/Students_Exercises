﻿namespace RentingCarsSystem.WEB.InputModels.Cars
{
    public enum CarSorting
    {
        Year,
        BrandAndModel,
        PricePerDay
    }
}
