﻿namespace RentingCarsSystem.WEB.InputModels.Cars
{
    public class CarServiceModel
    {
        public int Id { get; init; }

        public string Brand { get; init; }

        public string Model { get; init; }

        public string? CarPhoto { get; set; }

        public decimal Price { get; set; }

        public int Year { get; init; }

        public bool IsPublic { get; init; }

        public bool IsRented { get; init; }

        public string CategoryName { get; init; }
    }
}