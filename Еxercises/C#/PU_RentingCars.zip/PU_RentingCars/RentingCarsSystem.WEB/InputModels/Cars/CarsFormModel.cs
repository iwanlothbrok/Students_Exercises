﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Categories;
using System.ComponentModel.DataAnnotations;

namespace RentingCarsSystem.WEB.InputModels.Cars
{
    public class CarsFormModel
    {
        public int? Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Brand { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string Model { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string Description { get; set; } = null!;

        [Display(Name = "Photo of the car")]
        public string? CarPhoto { get; set; }

        [Required]
        [Display(Name = "Daily price")]
        public decimal Price { get; set; }

        [Display(Name = "Year of the car")]
        public int Year { get; set; }

        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        public string? CurrentUserId { get; set; }
        public IEnumerable<CategoryFormModel>? Categories { get; set; }
        public bool IsPublic { get; set; }
        public bool IsRented { get; set; }

        public int DealerId{ get; set; }
    }
}
