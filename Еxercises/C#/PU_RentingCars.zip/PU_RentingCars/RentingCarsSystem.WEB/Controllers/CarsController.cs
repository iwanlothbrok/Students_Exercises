﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentignCarsSystem.Web.Services.Cars;
using RentignCarsSystem.Web.Services.Categories;
using RentingCarsSystem.WEB.Extension;
using RentingCarsSystem.WEB.InputModels.Cars;
using RentingCarsSystem.WEB.Service.Dealers;
using System.Net.Http.Headers;

namespace RentingCarsSystem.WEB.Controllers
{
    [Authorize]
    public class CarsController : Controller
    {
        private readonly ICategoryServiceWeb categories;
        private readonly ICarsService carsService;
        private readonly IDealerService dealer;
        private readonly HttpClient _httpClient;

        public CarsController(ICategoryServiceWeb service, ICarsService carsService, HttpClient httpClient, IDealerService dealer)
        {
            this.carsService = carsService;
            _httpClient = httpClient;
            this.categories = service;
            this.dealer = dealer;
        }

        [HttpGet]
        public IActionResult Add()
        {
            var model = new CarsFormModel()
            {
                Categories = this.categories.GetCategories()
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Add(CarsFormModel carModel)
        {
            try
            {
                var userId = User.GetId();

                carModel.CurrentUserId = userId;

                var response = await _httpClient.PostAsJsonAsync($"https://localhost:7052/api/Cars/Add", carModel);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    var model = new CarsFormModel()
                    {
                        Categories = this.categories.GetCategories()
                    };
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                var model = new CarsFormModel()
                {
                    Categories = this.categories.GetCategories()
                };
                return View(model);

            }
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            CarsFormModel car = this.carsService.GetCarById(id);

            var dealer = this.dealer.GetDealerInfoById(User.GetId());


            if (car == null || car.DealerId != dealer.Id)
            {
                return RedirectToAction("All");
            }

            car.Categories = this.categories.GetCategories();

            return View(car);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(CarsFormModel car)
        {
            try
            {
                var userId = User.GetId();

                car.CurrentUserId = userId;

                var response = await _httpClient.PostAsJsonAsync($"https://localhost:7052/api/Cars/Edit", car);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        public async Task<IActionResult> DeleteAsync(int id)
        {
            try
            {
                CarsFormModel car = this.carsService.GetCarById(id);

                var dealer = this.dealer.GetDealerInfoById(User.GetId());


                if (car == null || car.DealerId != dealer.Id)
                {
                    return RedirectToAction("All");
                }

                // 'https://localhost:7052/api/Cars/Delete?id=0'
                var response = await _httpClient.GetAsync($"https://localhost:7052/api/Cars/Delete?id={id}");

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult All([FromQuery] AllCarsQueryModel query)
        {

            CarQueryServiceModel queryResult = this.carsService.All(
              query.Brand,
              query.SearchTerm,
              query.Sorting,
              query.CurrentPage,
              AllCarsQueryModel.CarsPerPage);

            IEnumerable<string> carBrands = this.carsService
               .AllBrands()
               .ToList();


            query.Brands = carBrands;
            query.TotalCars = queryResult.TotalCars;
            query.Cars = queryResult.Cars;


            query.Brands = carBrands;
            query.TotalCars = queryResult.TotalCars;
            query.Cars = queryResult.Cars;


            return View(query);
        }
    }
}
