﻿using Microsoft.AspNetCore.Mvc;
using RentingCarsSystem.WEB.Extension;
using RentingCarsSystem.WEB.InputModels.Dealers;
using RentingCarsSystem.WEB.Service.Dealers;

namespace RentingCarsSystem.WEB.Controllers
{
    public class DealerController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IDealerService dealer;
        private const string apiUrl = "https://localhost:7052/";
        public DealerController(HttpClient httpClient, IDealerService dealer)
        {
            _httpClient = httpClient;
            this.dealer = dealer;
        }

        [HttpGet]
        public IActionResult CreateDealer()
        {
            var model = new DealerFormViewModel();

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> CreateDealer(DealerFormViewModel dealerFormModel)
        {
            try
            {
                // Send form data to API controller
                var userId = User.GetId();
                dealerFormModel.UserId = userId;

                var response = await _httpClient.PostAsJsonAsync($"https://localhost:7052/api/Dealers", dealerFormModel);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    return View(dealerFormModel);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return View(dealerFormModel);
            }
        }


        [HttpGet]
        public IActionResult Edit(string id)
        {
            DealerFormViewModel model = this.dealer.GetDealerInfoById(id);

            if (model == null)
            {
                return BadRequest();
            }

            return View(model);
        }


        [HttpPost]
        public async Task<IActionResult> Edit(DealerFormViewModel dealer)
        {
            try
            {

                dealer.UserId = User.GetId();
                var dealerId = this.dealer.GetDealerIdByUserId(dealer.UserId);

                dealer.Id = dealerId;

                var response = await _httpClient.PostAsJsonAsync($"https://localhost:7052/api/Dealers/Edit", dealer);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return RedirectToAction("Index", "Home");
            }
        }

        [HttpGet]
        public async Task<IActionResult> DeleteAsync(string id)
        {
            try
            {
                // 'https://localhost:7052/api/Cars/Delete?id=0'
                var response = await _httpClient.GetAsync($"https://localhost:7052/api/Dealers/Delete?id={id}");

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    var errorResponse = await response.Content.ReadAsStringAsync();
                    ModelState.AddModelError("", errorResponse);
                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", "An error occurred while processing the request.");
                return RedirectToAction("Index", "Home");
            }
        }

    }
}