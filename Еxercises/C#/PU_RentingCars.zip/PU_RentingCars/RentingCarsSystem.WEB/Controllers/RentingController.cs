﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using RentignCarsSystem.Web.Services.Cars;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.Extension;
using RentingCarsSystem.WEB.InputModels.Renting;
using RentingCarsSystem.WEB.Service.Dealers;
using RentingCarsSystem.WEB.Service.Rent;

namespace RentingCarsSystem.WEB.Controllers
{
    public class RentingController : Controller
    {


        private readonly ICarsService carsSevice;
        private readonly IDealerService dealerService;
        private readonly IRentingService rentingService;

        public RentingController(ICarsService carsService, IDealerService dealerService, IRentingService rentingService)
        {
            this.carsSevice = carsService;
            this.dealerService = dealerService;
            this.rentingService = rentingService;
        }
        [HttpGet]
        public IActionResult Rent()
        {
            return View(new RentFormModel
            {
                Cars = this.carsSevice.AllCars().ToList(),
            });
        }

        [HttpPost]
        public IActionResult Rent(RentFormModel model)
        {
            string userId = this.User.GetId();
            int dealer = this.dealerService.GetDealerIdByUserId(userId);

            if (dealer != 0)
            {
                if (this.carsSevice.IsByDealer(model.CarId, dealer) == false)
                {
                    return BadRequest();
                }
            }

            DateTime dateOfBooking = DateTime.Parse(model.BookingDate);
            DateTime dateOfReturning = DateTime.Parse(model.ReturningDate);

            if (DateTime.Compare(dateOfBooking, dateOfReturning) > 0)
            {
                ModelState.AddModelError(model.BookingDate, "The given date is not correct!");
            }

            if (this.ModelState.IsValid == false)
            {
                return View(new RentFormModel
                {
                    Cars = this.carsSevice.AllCars().ToList(),
                });
            }

            int carId = model.CarId;
            var car = this.carsSevice.GetCarById(carId);

            if (car.IsRented == true)
            {
                return BadRequest();
            }

            decimal price = car.Price;


            if (price < 0)
            {
                return RedirectToAction("Error", "Home");
            }
            bool isValid = this.rentingService.CreateBooking(model.CustomerFirstName, model.CustomerLastName, model.CustomerPhoneNumber, userId, car.DealerId, model.BookingDate, price, model.ReturningDate, model.CarId, model.Address);

            if (isValid == false)
            {
                return BadRequest();
            }

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        [Authorize]
        public IActionResult GetOfferts()
        {
            var userId = User.GetId();
            var rentings = this.rentingService.GetOffertsByUserId(userId);

            return View(rentings);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            if(this.rentingService.Delete(id) == false)
            {
                return BadRequest();
            }

            return RedirectToAction("Index", "Home");
        }
    }
}
