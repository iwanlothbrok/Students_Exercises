﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Dealers;

namespace RentingCarsSystem.WEB.Service.Dealers
{
    public class DealerService : IDealerService
    {
        public readonly ApplicationDbContext data;

        public DealerService(ApplicationDbContext data)
        {
            this.data = data;
        }

        public int GetDealerIdByUserId(string id)
        => this.data.Dealers.Where(d => d.UserId == id).Select(d => d.Id).FirstOrDefault();

        public DealerFormViewModel? GetDealerInfoById(string id)
        {
            var dealer = this.data.Dealers.Where(d => d.UserId == id).FirstOrDefault();

            if (dealer == null)
            {
                return null;
            }

            return new DealerFormViewModel
            {
                Id = dealer.Id,
                Bullstat = dealer.Bullstat,
                CompanyName = dealer.CompanyName,
                FirstName = dealer.FirstName,
                LastName = dealer.LastName,
                Location = dealer?.Location,
                PhoneNumber = dealer.Phone,
                UserId = dealer?.UserId,
            };
        }
    }
}
