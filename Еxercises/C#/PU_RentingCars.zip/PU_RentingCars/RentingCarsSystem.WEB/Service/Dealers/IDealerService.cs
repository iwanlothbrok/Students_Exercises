﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Dealers;

namespace RentingCarsSystem.WEB.Service.Dealers
{
    public interface IDealerService
    {
        DealerFormViewModel? GetDealerInfoById(string id);
        int GetDealerIdByUserId(string id);
    }
}
