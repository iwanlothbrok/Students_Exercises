﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentignCarsSystem.Web.Services.Cars
{
    public interface ICarsService
    {
        CarsFormModel GetCarById(int id);
        IEnumerable<string> AllBrands();
        bool IsByDealer(int carId, int dealerId);
        IEnumerable<RentCarModel> AllCars();
        IEnumerable<CarServiceModel> GetCars(IQueryable<Car> carQuery);
        CarQueryServiceModel All(
          string brand = null,
          string searchTerm = null,
          CarSorting sorting = CarSorting.BrandAndModel,
          int currentPage = 1,
          int carsPerPage = int.MaxValue,
           bool publicOnly = true,
           bool IsRented = false);
    }
}
