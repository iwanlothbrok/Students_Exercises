﻿using AutoMapper.QueryableExtensions;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentignCarsSystem.Web.Services.Cars
{
    public class CarsService : ICarsService
    {
        private readonly ApplicationDbContext data;

        public CarsService(ApplicationDbContext data)
        {
            this.data = data;
        }

        public bool IsByDealer(int carId, int dealerId)
        {
            var car = this.data.Cars.Find(carId);

            if (car.DealerId == dealerId)
            {
                return false;
            }

            return true;
        }
        public CarsFormModel GetCarById(int id)
        {
            var car = this.data.Cars.Where(car => car.Id == id).FirstOrDefault();


            if (car== null)
            {
                return null;
            }

            // Map Category entities to CategoryFormModel instances
            CarsFormModel carModel = new CarsFormModel();

            carModel.Id = car.Id;
            carModel.CategoryId = car.CategoryId;
            carModel.Description = car.Description;
            carModel.CarPhoto = car.CarPhoto;
            carModel.Brand = car.Brand;
            carModel.Model = car.Model;
            carModel.Price = car.PricePerDay;
            carModel.IsRented = car.IsRented;
            carModel.IsPublic = car.IsPublic;
            carModel.Year = car.Year;
            carModel.DealerId = car.DealerId;

            return carModel;
        }

        public CarQueryServiceModel All(
          string brand = null,
          string searchTerm = null,
          CarSorting sorting = CarSorting.BrandAndModel,
          int currentPage = 1,
          int carsPerPage = int.MaxValue,
           bool publicOnly = true,
           bool IsRented = false)
        {
            var carsQuery = this.data.Cars
                                .Where(p => p.IsPublic == publicOnly && p.IsRented == IsRented);

            if (!string.IsNullOrWhiteSpace(brand))
            {
                carsQuery = carsQuery.Where(c => c.Brand == brand);
            }

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                carsQuery = carsQuery.Where(c =>
                    (c.Brand + " " + c.Model).ToLower().Contains(searchTerm.ToLower())
                    || c.Description.ToLower().Contains(searchTerm.ToLower()));

            }

            carsQuery = sorting switch
            {
                CarSorting.Year => carsQuery.OrderByDescending(c => c.Year),
                CarSorting.PricePerDay => carsQuery.OrderBy(c => c.PricePerDay),
                CarSorting.BrandAndModel => carsQuery.OrderBy(c => c.Brand).ThenBy(c => c.Model),
            };

            int totalCars = carsQuery.Count();

            IEnumerable<CarServiceModel> cars = GetCars(carsQuery
                .Skip((currentPage - 1) * carsPerPage)
                .Take(carsPerPage))
                .ToList();

            return new CarQueryServiceModel
            {
                TotalCars = totalCars,
                CurrentPage = currentPage,
                CarsPerPage = carsPerPage,
                Cars = cars
            };
        }

        public IEnumerable<CarServiceModel> GetCars(IQueryable<Car> car)
        {
            var carModel = car.Select(c => new CarServiceModel
            {

                Id = c.Id,
                CarPhoto = c.CarPhoto,
                Brand = c.Brand,
                Model = c.Model,
                Price = c.PricePerDay,
                IsRented = c.IsRented,
                IsPublic = c.IsPublic,
                Year = c.Year,

            }).ToList();

            return carModel;
        }


        public IEnumerable<string> AllBrands()
         => this.data
              .Cars
              .Select(c => c.Brand)
              .Distinct()
              .OrderBy(br => br)
              .ToList();


        public IEnumerable<RentCarModel> AllCars()
       => this.data
             .Cars
             .Select(c => new RentCarModel
             {
                 Id = c.Id,
                 Brand = c.Brand,
                 Model = c.Model,
                 Year = c.Year,
                 Price = c.PricePerDay,
                 IsRented = c.IsRented,
                 IsPublic = c.IsPublic,
             })
             .ToList();

    }
}
