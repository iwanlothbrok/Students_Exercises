﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Categories;

namespace RentignCarsSystem.Web.Services.Categories
{
    public class CategoryServiceWeb : ICategoryServiceWeb
    {
        private readonly ApplicationDbContext db;

        public CategoryServiceWeb(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IEnumerable<CategoryFormModel> GetCategories()
        {
            var categories = this.db.Categories.ToList();

            // Map Category entities to CategoryFormModel instances
            var categoryFormModels = categories.Select(category => new CategoryFormModel
            {
                Id = category.Id,
                Name = category.Name,
            });

            return categoryFormModels;
        }

    }
}
