﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Categories;

namespace RentignCarsSystem.Web.Services.Categories
{
    public interface ICategoryServiceWeb
    {
        IEnumerable<CategoryFormModel>? GetCategories();
    }
}
