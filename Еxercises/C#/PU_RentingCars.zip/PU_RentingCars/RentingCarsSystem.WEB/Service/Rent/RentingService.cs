﻿using RentignCarsSystem.Web.Services.Cars;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Renting;

namespace RentingCarsSystem.WEB.Service.Rent
{
    public class RentingService : IRentingService
    {
        private readonly ApplicationDbContext data;
        private readonly ICarsService car;

        public RentingService(ApplicationDbContext data, ICarsService car)
        {
            this.data = data;
            this.car = car;
        }

        public bool CreateBooking(string firstName, string lastName, long phoneNumber, string userId, int dealerId, string bookingDate, decimal price, string returingDate, int carId, string address)
        {
            decimal allPrice = GetCarPrice(bookingDate, returingDate, price);

            if (allPrice <= 0)
            {
                return false;
            }

            Renting rent = new Renting
            {
                RenterName = firstName,
                RenterLast = lastName,
                DealerId = dealerId,
                StartDate = DateTime.Parse(bookingDate),
                EndDate = DateTime.Parse(returingDate),
                Phone = phoneNumber,
                IdentityUserId = userId,
                TotalSum = allPrice,
                Address = address,
                CarId = carId
            };

            var car = this.car.GetCarById(carId);

            car.IsPublic = false;
            car.IsRented = true;

            this.data.Rentings.Add(rent);
            this.data.SaveChanges();

            return true;
        }

        public bool Delete(int id)
        {
            var renting = this.data.Rentings.Find(id);

            if (renting == null)
            {
                return false;
            }

            this.data.Remove(renting);
            this.data.SaveChanges();

            return true;

        }

        public decimal GetCarPrice(string bookingDate, string returingDate, decimal price)
        {
            var dateOfBooking = DateTime.Parse(bookingDate);
            var dateOfReturning = DateTime.Parse(returingDate);

            if (DateTime.Compare(dateOfBooking, dateOfReturning) > 0)
            {
                return -1;
            }
            TimeSpan diff = dateOfReturning - dateOfBooking;
            int days = diff.Days;

            if (days <= 0)
            {
                return -1;
            }

            decimal totalPrice = price * days;

            return totalPrice;
        }

        public IEnumerable<Renting>? GetOffertsByUserId(string userId)
        {
            return this.data.Rentings.Where(rent => rent.IdentityUserId == userId).ToList();
        }
    }
}
