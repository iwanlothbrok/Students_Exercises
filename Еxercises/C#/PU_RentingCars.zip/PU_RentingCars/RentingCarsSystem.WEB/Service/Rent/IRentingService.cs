﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Renting;

namespace RentingCarsSystem.WEB.Service.Rent
{
    public interface IRentingService
    {
        bool CreateBooking(string firstName, string lastName, long phoneNumber, string userId, int dealerId, string bookingDate, decimal price, string returingDate, int carId, string address);
        decimal GetCarPrice(string bookingDate, string returingDate, decimal price);

        IEnumerable<Renting>? GetOffertsByUserId(string userId);

        bool Delete(int id);
    }
}
