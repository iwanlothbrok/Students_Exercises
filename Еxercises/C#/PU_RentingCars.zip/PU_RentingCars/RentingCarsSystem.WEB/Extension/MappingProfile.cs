﻿using AutoMapper;
using RentingCarsSystem.WEB.InputModels.Dealers;
using RentingCarsSystem.Data.Data.Models;

namespace RentingCarsSystem.WEB.Extension
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            //mapping for books
            this.CreateMap<Dealer, DealerFormViewModel>();
            this.CreateMap<DealerFormViewModel, Dealer>();
     
        }
    }
}
