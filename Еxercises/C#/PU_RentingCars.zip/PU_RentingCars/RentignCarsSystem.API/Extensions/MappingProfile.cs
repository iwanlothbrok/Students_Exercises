﻿using AutoMapper;
using RentingCarsSystem.WEB.InputModels.Dealers;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentingCarsSystem.Api.Extension
{
    public class MappingProfile: Profile
    {
        public MappingProfile()
        {
            //mapping for dealers
            this.CreateMap<Dealer, DealerFormViewModel>();
            this.CreateMap<DealerFormViewModel, Dealer>();


            // mapping for cars
            this.CreateMap<IQueryable<Car>, CarServiceModel>();
            this.CreateMap<Car, CarServiceModel>();
            CreateMap<Car, CarServiceModel>();
            CreateMap<CarServiceModel,Car>();
        }
    }
}
