﻿using Microsoft.AspNetCore.Mvc;
using RentingCarsSystem.Api.Services.Dealers;
using RentingCarsSystem.WEB.InputModels.Dealers;

namespace RentignCarsSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DealersController : ControllerBase
    {
        private readonly IDealerService _dealerService;

        public DealersController(IDealerService dealerService)
        {
            _dealerService = dealerService;
        }

        [HttpPost]
        public IActionResult CreateDealer([FromBody] DealerFormViewModel dealerFormModel)
        {

            // Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Call dealer service to add dealer to database
            if (_dealerService.CreateDealer(dealerFormModel) == -1)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

        [HttpPost("Edit")]
        public IActionResult Edit([FromBody] DealerFormViewModel model)
        {
            if (_dealerService.Edit(model) == false)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

        [HttpGet("Delete")]
        public IActionResult Delete(string id)
        {
            // Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (_dealerService.Delete(id) == false)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

    }
}
