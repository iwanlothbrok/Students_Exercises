﻿
using Microsoft.AspNetCore.Mvc;
using RentignCarsSystem.API.Services.Cars;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentignCarsSystem.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarsController : ControllerBase
    {
        private readonly ICarsService cars;

        public CarsController(ICarsService cars)
        {
            this.cars = cars;
        }

        [HttpPost("Add")]
        public async Task<IActionResult> AddCarAsync([FromBody] CarsFormModel model)
        {
            // Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (await cars.AddCarAsync(model, model.CurrentUserId) == -1)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

        [HttpPost("Edit")]
        public IActionResult EditCar([FromBody] CarsFormModel model)
        {
            // Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (cars.Edit(model) == false)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }

        [HttpGet("Delete")]
        public IActionResult Delete(int id)
        {
            // Check if model state is valid
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (cars.Delete(id) == false)
            {
                return BadRequest(ModelState);
            }

            return Ok();
        }
    }
}
