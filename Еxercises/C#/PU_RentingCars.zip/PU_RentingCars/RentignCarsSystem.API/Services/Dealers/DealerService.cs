﻿using AutoMapper;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Dealers;

namespace RentingCarsSystem.Api.Services.Dealers
{
    public class DealerService : IDealerService
    {

        private readonly ApplicationDbContext data;
        private readonly IMapper mapper;

        public DealerService(ApplicationDbContext date, IMapper mapper)
        {
            this.data = date;
            this.mapper = mapper;
        }

        public Dealer? GetDealerByUserId(string userId)
            => this.data.Dealers.Where(x => x.UserId == userId).FirstOrDefault();
        public int CreateDealer(DealerFormViewModel model)
        {

            if (model.UserId == null)
            {
                return -1;
            }
            try
            {
                if (GetDealerByUserId(model.UserId) != null)
                {
                    return -1;
                }
            }
            catch (Exception)
            {

            }
            Dealer newDealer = this.mapper.Map<Dealer>(model);
            newDealer.UserId = model.UserId;
            newDealer.RegistrationDate = DateTime.Now;

            this.data.Add(newDealer);
            this.data.SaveChanges();

            return 1;
        }


        public Dealer? GetDealerById(int id)
            => this.data.Dealers.Find(id);


        public bool Edit(DealerFormViewModel model)
        {
            Dealer? dealerData = this.data.Dealers.Where(d => d.UserId == model.UserId).FirstOrDefault();


            if (dealerData == null)
            {
                return false;
            }

            dealerData.Id = model.Id;
            dealerData.Bullstat = model.Bullstat;
            dealerData.CompanyName = model.CompanyName;
            dealerData.FirstName = model.FirstName;
            dealerData.LastName = model.LastName;
            dealerData.Location = model?.Location;
            dealerData.Phone = (long)(model?.PhoneNumber);

            this.data.SaveChanges();


            return true;
        }

        public bool Delete(string id)
        {
             var dealer = this.data.Dealers.Where(uId => uId.UserId == id).FirstOrDefault();

            if (dealer == null)
            {
                return false;
            }

            this.data.Remove(dealer);
            this.data.SaveChanges();

            return true;
        }
    }

}
