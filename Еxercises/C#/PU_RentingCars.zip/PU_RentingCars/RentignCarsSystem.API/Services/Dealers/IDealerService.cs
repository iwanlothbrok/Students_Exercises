﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Dealers;

namespace RentingCarsSystem.Api.Services.Dealers
{
    public interface IDealerService
    {
        bool Delete(string userId);
        Dealer? GetDealerById(int id);
        Dealer? GetDealerByUserId(string userId);
        int CreateDealer(DealerFormViewModel model);
        bool Edit(DealerFormViewModel model);
    }
}
