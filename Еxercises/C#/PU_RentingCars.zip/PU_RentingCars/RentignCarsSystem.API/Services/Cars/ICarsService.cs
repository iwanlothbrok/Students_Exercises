﻿using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentignCarsSystem.API.Services.Cars
{
    public interface ICarsService
    {
        bool Delete(int carId);
        bool Edit(CarsFormModel model);

        IEnumerable<string> AllBrands();
       IEnumerable<CarServiceModel> GetCars(IQueryable<Car> carQuery);
        Task<int> AddCarAsync(CarsFormModel model, string userId);
        CarQueryServiceModel All(
          string brand = null,
          string searchTerm = null,
          CarSorting sorting = CarSorting.BrandAndModel,
          int currentPage = 1,
          int carsPerPage = int.MaxValue,
           bool publicOnly = true,
           bool IsRented = false);

    }
}
