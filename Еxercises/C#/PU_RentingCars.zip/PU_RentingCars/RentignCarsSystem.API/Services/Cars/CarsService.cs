﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using RentingCarsSystem.Api.Services.Dealers;
using RentingCarsSystem.Data.Data.Models;
using RentingCarsSystem.WEB.InputModels.Cars;

namespace RentignCarsSystem.API.Services.Cars
{
    public class CarsService : ICarsService
    {
        private readonly IDealerService dealer;
        private readonly ApplicationDbContext data;
        private readonly IMapper mapper;

        public CarsService(IDealerService dealer, ApplicationDbContext data, IMapper mapper)
        {
            this.dealer = dealer;
            this.data = data;
            this.mapper = mapper;
        }

        public async Task<int> AddCarAsync(CarsFormModel model, string userId)
        {
            var currentDealer = dealer.GetDealerByUserId(userId);

            if (currentDealer == null)
            {
                return -2;
            }

            var carData = new Car
            {
                Brand = model.Brand,
                Model = model.Model,
                PricePerDay = model.Price,
                CarPhoto = model.CarPhoto,
                Description = model.Description,
                Year = model.Year,
                CategoryId = model.CategoryId,
                DealerId = currentDealer.Id,
                IsPublic = true,
                IsRented = false
            };

            await this.data.AddAsync(carData);
            await this.data.SaveChangesAsync();

            return carData.Id;
        }

        public bool Delete(int carId)
        {
            var car = this.data.Cars.Find(carId);

            if (car == null)
            {
                return false;
            }

            this.data.Remove(car);
            this.data.SaveChanges();


            return true;
        }

        public bool Edit(CarsFormModel model)
        {
            if (this.data.Cars.Find(model.Id) == null)
            {
                return false;
            }

            Car? carData = this.data.Cars.Find(model.Id);

            var dealer = this.dealer.GetDealerByUserId(model.CurrentUserId);

            if (carData == null)
            {
                return false;
            }

            carData.CategoryId = model.CategoryId;
            carData.Description = model.Description;
            carData.CarPhoto = model.CarPhoto;
            carData.Brand = model.Brand;
            carData.Model = model.Model;
            carData.PricePerDay = model.Price;
            carData.IsRented = model.IsRented;
            carData.IsPublic = model.IsPublic;
            carData.Year = model.Year;
            carData.DealerId = dealer.Id;
            carData.IsPublic = true;

            this.data.SaveChanges();

            return true;
        }

        public CarQueryServiceModel All(
           string brand = null,
           string searchTerm = null,
           CarSorting sorting = CarSorting.BrandAndModel,
           int currentPage = 1,
           int carsPerPage = int.MaxValue,
            bool publicOnly = true,
            bool IsRented = false)
        {
            var carsQuery = this.data.Cars
                                .Where(p => p.IsPublic == publicOnly && p.IsRented == IsRented);

            if (!string.IsNullOrWhiteSpace(brand))
            {
                carsQuery = carsQuery.Where(c => c.Brand == brand);
            }

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                carsQuery = carsQuery.Where(c =>
                    (c.Brand + " " + c.Model).ToLower().Contains(searchTerm.ToLower())
                    || c.Description.ToLower().Contains(searchTerm.ToLower()));

            }

            carsQuery = sorting switch
            {
                CarSorting.Year => carsQuery.OrderByDescending(c => c.Year),
                CarSorting.PricePerDay => carsQuery.OrderBy(c => c.PricePerDay),
                CarSorting.BrandAndModel => carsQuery.OrderBy(c => c.Brand).ThenBy(c => c.Model),
            };

            int totalCars = carsQuery.Count();

            IEnumerable<CarServiceModel> cars = GetCars(carsQuery
                .Skip((currentPage - 1) * carsPerPage)
                .Take(carsPerPage))
                .ToList();

            return new CarQueryServiceModel
            {
                TotalCars = totalCars,
                CurrentPage = currentPage,
                CarsPerPage = carsPerPage,
                Cars = cars
            };
        }

        public IEnumerable<CarServiceModel> GetCars(IQueryable<Car> carQuery)
             => carQuery
                 .ProjectTo<CarServiceModel>(this.mapper.ConfigurationProvider)
                 .ToList();


        public IEnumerable<string> AllBrands()
         => this.data
              .Cars
              .Select(c => c.Brand)
              .Distinct()
              .OrderBy(br => br)
              .ToList();
    }
}
