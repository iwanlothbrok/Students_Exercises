﻿using RentingCarsSystem.Data.Data.Models;

namespace RentignCarsSystem.API.Services.Categories
{
    public class CategoryService : ICategoryService
    {
        private readonly ApplicationDbContext db;

        public CategoryService(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IEnumerable<Category>? GetCategories()
            => this.db.Categories.ToList();
    }
}
