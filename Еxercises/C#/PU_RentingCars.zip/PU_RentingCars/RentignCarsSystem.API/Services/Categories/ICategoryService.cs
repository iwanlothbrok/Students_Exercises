﻿using RentingCarsSystem.Data.Data.Models;

namespace RentignCarsSystem.API.Services.Categories
{
    public interface ICategoryService
    {
        IEnumerable<Category>? GetCategories();

    }
}
