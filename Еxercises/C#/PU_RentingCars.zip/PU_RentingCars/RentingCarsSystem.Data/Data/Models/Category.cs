﻿using System.ComponentModel.DataAnnotations;

namespace RentingCarsSystem.Data.Data.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Name { get; set; } = null!;

        public List<Car>? Cars { get; init; } = new List<Car>();
    }
}
