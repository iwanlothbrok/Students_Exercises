﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentingCarsSystem.Data.Data.Models
{
    public class Renting
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string RenterName { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string RenterLast{ get; set; }= null!;

        [Required]
        [StringLength(50)]
        public string Address{ get; set; } = null!;

        [Required]
        [StringLength(50)]
        public long Phone { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        [Required]
        public decimal TotalSum { get; set; }

       
        public int CarId { get; set; }
        public Car Car { get; set; }

        public int DealerId { get; set; }
        public  Dealer Dealer { get; set; }

        [Required]
        public string IdentityUserId { get; set; } = null!;

        [ForeignKey(nameof(IdentityUserId))]
        public IdentityUser? IdentityUser { get; set; }
    }
}
