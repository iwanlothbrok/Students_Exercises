﻿namespace RentingCarsSystem.Data.Data.Models
{
    using Microsoft.AspNetCore.Identity;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Dealer
    {
        [Key]
        public int Id { get; set; }
        public string? CompanyName { get; set; }

        [Required]
        [StringLength(50)]
        public string FirstName { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string LastName { get; set; } = null!;

        //[StringLength(13)]
        public long Phone { get; set; }

        [Required, StringLength(50)]
        public string Location { get; set; } = null!;

        // 9 cifri
        public long? Bullstat { get; set; }

        public DateTime RegistrationDate { get; set; }

        public bool IsActive { get; set; }

        public string? UserId { get; set; }
        public List<Car> Cars { get; set; } = new List<Car>();
    }
}
