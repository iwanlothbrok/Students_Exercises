﻿namespace RentingCarsSystem.Data.Data.Models
{
    using Microsoft.AspNetCore.Identity;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    public class Car
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(50)]
        public string Brand { get; set; } = null!;

        [Required]
        [StringLength(50)]
        public string Model { get; set; } = null!;

        [Range(2007, 2040)]
        public int Year { get; set; }
        public string Description { get; set; }
        public decimal PricePerDay { get; set; }

        [Required]
        public string? CarPhoto { get; set; }

        public int DealerId { get; set; }
        public Dealer Dealer { get; set; }

        public int CategoryId { get; set; }
        public Category Category { get; set; }

        public string? RenterId { get; set; }
        [ForeignKey(nameof(RenterId))]
        public IdentityUser IdentityUser { get; set; }

        public bool IsPublic { get; set; }
        public bool IsRented { get; set; }
    }
}
