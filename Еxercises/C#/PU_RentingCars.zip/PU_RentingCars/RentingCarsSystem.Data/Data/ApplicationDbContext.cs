﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace RentingCarsSystem.Data.Data.Models
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder
                 .Entity<Car>()
                 .HasOne(c => c.Category)
                 .WithMany(c => c.Cars)
                 .HasForeignKey(c => c.CategoryId)
                 .OnDelete(DeleteBehavior.Restrict);


            builder
                 .Entity<Car>()
                 .HasOne(c => c.Dealer)
                 .WithMany(c => c.Cars)
                 .HasForeignKey(c => c.DealerId)
                 .OnDelete(DeleteBehavior.Restrict);

            //builder.Entity<Renting>()
            //  .HasOne(d=>d.Dealer)
            //  .WithOne()
            //  .HasForeignKey<Dealer>(c => c.IdentityUserId)
            //  .OnDelete(DeleteBehavior.Restrict);
            builder.Entity<Category>().HasData(
                    new Category { Id = 1, Name = "Mini" },
                    new Category { Id = 2, Name = "Economy" },
                    new Category { Id = 3, Name = "Midsize" },
                    new Category { Id = 4, Name = "Large" },
                    new Category { Id = 5, Name = "SUV" },
                    new Category { Id = 6, Name = "Vans" },
                    new Category { Id = 7, Name = "Luxury" }
                );


            base.OnModelCreating(builder);
        }

        public DbSet<Car> Cars { get; set; }
        public DbSet<Renting> Rentings { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Dealer> Dealers { get; set; }
    }
}